
For building the testprograms , we can use codeblock IDE and make


for compiling make, 

make -f dnp3servertest.mak
make -f dnp3clienttest.mak